<?php

namespace Agenciamav\LaravelIfood\Http\Controllers;

use Agenciamav\LaravelIfood\IfoodClient;

class CatalogItem
{
    use IfoodClient;
    public function createItem()
    {
    }
    public function updateItem()
    {
    }

    public function deleteItem()
    {
    }
    public function updateItemStatus()
    {
    }
}
