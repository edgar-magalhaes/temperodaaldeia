<?php

namespace Agenciamav\LaravelIfood\Http\Controllers;

use Agenciamav\LaravelIfood\IfoodClient;

class CatalogOption
{
    use IfoodClient;
    public function createOption()
    {
    }
    public function updateOption()
    {
    }

    public function deleteOption()
    {
    }
}
