<?php

namespace Agenciamav\LaravelIfood\Http\Controllers;

use Agenciamav\LaravelIfood\IfoodClient;

class CatalogPizza
{
    use IfoodClient;
    public function createPizza()
    {
    }
    public function getPizzas()
    {
    }
    public function linkPizza()
    {
    }
    public function unlinkPizza()
    {
    }
    public function editPizza()
    {
    }
    public function updatePizzaStatus()
    {
    }
    public function updatePizzaPricesBatch()
    {
    }
}
