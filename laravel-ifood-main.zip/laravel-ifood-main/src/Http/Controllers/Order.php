<?php

namespace Agenciamav\LaravelIfood\Http\Controllers;

use Illuminate\Database\Eloquent\Model;

class IfoodOrder extends Model
{
    protected $fillable = [];

    protected $casts = [];
}
