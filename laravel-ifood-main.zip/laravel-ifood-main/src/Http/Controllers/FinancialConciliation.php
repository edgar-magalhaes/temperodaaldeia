<?php

namespace Agenciamav\LaravelIfood\Http\Controllers;

use Agenciamav\LaravelIfood\IfoodClient;

class FinancialConciliation
{
    use IfoodClient;
    public function listSales()
    {
    }
    public function listPayments()
    {
    }
    public function listOccurrences()
    {
    }
    public function listMaintenanceFees()
    {
    }
    public function listIncomeTaxes()
    {
    }
    public function listChargeCancellations()
    {
    }
}
