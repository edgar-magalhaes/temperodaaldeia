<?php

namespace Agenciamav\LaravelIfood\Http\Controllers;

use Agenciamav\LaravelIfood\IfoodClient;

class OrderDelivery
{
    use IfoodClient;
    public function getTracking()
    {
    }
}
