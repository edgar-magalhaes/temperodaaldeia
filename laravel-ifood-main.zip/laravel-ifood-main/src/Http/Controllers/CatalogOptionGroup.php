<?php

namespace Agenciamav\LaravelIfood\Http\Controllers;

use Agenciamav\LaravelIfood\IfoodClient;

class CatalogOptionGroup
{
    use IfoodClient;
    public function createOptionGroup()
    {
    }
    public function getOptionGroups()
    {
    }

    public function updateOptionGroup()
    {
    }
    public function deleteOptionGroup()
    {
    }
    public function associateOptionGroupToProduct()
    {
    }
    public function updateOptionGroupToProduct()
    {
    }
    public function disassociateOptionGroupToProduct()
    {
    }
    public function updateOptionGroupStatus()
    {
    }
}
