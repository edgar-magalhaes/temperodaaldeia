# Changelog

All notable changes to `laravel-ifood` will be documented in this file

## 1.0.0 - 2021-05-04

- First release. Just authentication module with authorization code flow.
